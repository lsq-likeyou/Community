create unique index PRIMARY_KEY_C
    on USER (ID);

