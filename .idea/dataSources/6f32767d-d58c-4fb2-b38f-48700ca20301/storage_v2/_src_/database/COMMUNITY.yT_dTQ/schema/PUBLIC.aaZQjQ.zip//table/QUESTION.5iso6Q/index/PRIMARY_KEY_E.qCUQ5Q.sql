create unique index PRIMARY_KEY_E
    on QUESTION (ID);

